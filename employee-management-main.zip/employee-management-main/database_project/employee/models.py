from django.db import models
# from django.db.models.signals import post_save
# from django.dispatch import receiver
# from datetime import datetime, timedelta
# from dateutil import rrule, parser
# import calendar

class Department(models.Model):
    dept_id = models.AutoField(primary_key=True, auto_created=True)
    dept_name = models.CharField(max_length=50)
    location = models.TextField(max_length=100)

    def __str__(self):
        return f"{self.dept_name}"


class Employee(models.Model):
    emp_id = models.AutoField(primary_key=True, auto_created=True)
    name = models.CharField(max_length=40)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    designation = models.TextField(max_length=50)
    salary = models.FloatField()
    hire_date = models.DateField()
    department = models.ForeignKey(Department, on_delete=models.DO_NOTHING)

    def __str__(self):
        return f"{self.name}"
    

# def getLastDays(start_date: datetime, end_date: datetime) -> list:
#     rv = []
#     start_date = datetime(start_date.year, start_date.month, 1)
#     for dt in rrule.rrule(rrule.MONTHLY, dtstart=start_date, until=end_date):            
#         lastday = calendar.monthrange(dt.year, dt.month)
#         rv.append(datetime(dt.year, dt.month, lastday[1]))
#     return rv


# @receiver(post_save, sender=Employee)
# def triggerEmployeePayroll(sender, instance, **kwargs):
#     start_date = parser.parse(instance.hire_date)
#     end_date = datetime.now()
#     for dt in getLastDays(start_date, end_date):
#         if dt < end_date:
#             Payroll.objects.create(emp_id=instance, amount=instance.salary, paid_date=dt)


class Project(models.Model):
    proj_id = models.AutoField(primary_key=True, auto_created=True)
    name = models.CharField(max_length=100)
    start_date = models.DateField()
    end_date = models.DateField()
    dept_id = models.ForeignKey(Department, on_delete=models.DO_NOTHING)
    budget = models.FloatField()

    def __str__(self):
        return f"{self.name}"


class EmployeeProject(models.Model):
    id = models.AutoField(primary_key=True, auto_created=True)
    emp_id = models.ForeignKey(Employee, on_delete=models.DO_NOTHING)
    proj_id = models.ForeignKey(Project, on_delete=models.DO_NOTHING)
    join_date = models.DateField()

    def __str__(self):
        return f"{self.emp_id.name}-{self.proj_id.name}"


class Payroll(models.Model):
    pay_id = models.AutoField(primary_key=True, auto_created=True)
    emp_id = models.ForeignKey(Employee, on_delete=models.DO_NOTHING)
    amount = models.FloatField()
    paid_date = models.DateField()

    def __str__(self):
        return f"{self.emp_id.name}-{self.amount}"


class LeaveApplication(models.Model):
    appl_id = models.AutoField(primary_key=True, auto_created=True)
    emp_id = models.ForeignKey(Employee, on_delete=models.DO_NOTHING)
    no_of_days = models.IntegerField(default=1)
    from_date = models.DateField()
    to_date = models.DateField()
    reason_for_leave = models.TextField(max_length=500)
    approved = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.emp_id.name}-{self.appl_id}-{self.approved}"


class Dependents(models.Model):
    member_id = models.AutoField(primary_key=True, auto_created=True)
    name = models.CharField(max_length=40)
    relationship = models.CharField(max_length=20)
    occupation = models.CharField(max_length=30)
    emp_id = models.ForeignKey(Employee, on_delete=models.DO_NOTHING)

    def __str__(self):
        return f"{self.emp_id.name}-{self.relationship}-{self.name}"
