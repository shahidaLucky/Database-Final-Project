from django import forms
from .models import (
    Employee,
    Department,
    Project,
    EmployeeProject,
    Payroll,
    LeaveApplication,
    Dependents,
)


class DepartmentForm(forms.ModelForm):
    class Meta:
        model = Department
        fields = ["dept_name", "location"]

        labels = {"dept_name": "Department Name", "location": "Location"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["dept_name"].widget.attrs.update(
            {"class": "form-control", "placeholder": "Department Name"}
        )
        self.fields["location"].widget.attrs.update(
            {"class": "form-control", "placeholder": "Location"}
        )


class DepartmentUpdateForm(forms.ModelForm):
    class Meta:
        model = Department
        fields = ["dept_id", "dept_name", "location"]


class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = "__all__"
        exclude = ("id",)
        widgets = {
            "designation": forms.TextInput(attrs={"size": 20}),
            "hire_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            ),
        }


class EmployeeUpdateForm(forms.ModelForm):
    department = forms.ModelChoiceField(
        queryset=Department.objects.all(),
        label="Department",
    )

    class Meta:
        model = Employee
        fields = "__all__"
        widgets = {
            "designation": forms.TextInput(attrs={"size": 20}),
            "hire_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            ),
        }


class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = "__all__"
        exclude = ("proj_id",)
        labels = {
            "dept_id": "Department Name",
            "start_date": "Start Date",
            "end_date": "End Date",
            "budget": "Budget",
            "proj_id": "Project ID",
        }
        widgets = {
            "start_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            ),
            "end_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            ),
        }


class ProjectUpdateForm(forms.ModelForm):
    dept_id = forms.ModelChoiceField(
        queryset=Department.objects.all(),
        label="Department",
    )

    class Meta:
        model = Project
        fields = "__all__"
        labels = {"dept_id": "Department Name"}
        widgets = {
            "start_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            ),
            "end_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            ),
        }


class EmployeeProjectForm(forms.ModelForm):
    class Meta:
        model = EmployeeProject
        fields = "__all__"
        exclude = ("id",)
        labels = {
            "emp_id": "Employee Name",
            "join_date": "Join Date",
            "proj_id": "Project Name",
        }
        widgets = {
            "join_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            )
        }


class EmployeeProjectUpdateForm(forms.ModelForm):
    emp_id = forms.ModelChoiceField(
        queryset=Employee.objects.all(),
        label="Employee Name",
    )
    proj_id = forms.ModelChoiceField(
        queryset=Project.objects.all(),
        label="Project Name",
    )

    class Meta:
        model = EmployeeProject
        fields = "__all__"
        labels = {"join_date": "Join Date"}
        widgets = {
            "join_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            )
        }


class PayrollForm(forms.ModelForm):
    class Meta:
        model = Payroll
        fields = "__all__"
        exclude = ("pay_id",)
        labels = {
            "emp_id": "Employee",
            "amount": "Amount",
            "paid_date": "Paid Date",
        }
        widgets = {
            "paid_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            )
        }


class PayrollUpdateForm(forms.ModelForm):
    emp_id = forms.ModelChoiceField(
        queryset=Employee.objects.all(),
        label="Employee",
    )

    class Meta:
        model = Payroll
        fields = "__all__"
        labels = {
            "amount": "Amount",
            "paid_date": "Paid Date",
        }
        widgets = {
            "paid_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            )
        }


class LeaveForm(forms.ModelForm):
    class Meta:
        model = LeaveApplication
        fields = "__all__"
        exclude = ("appl_id",)
        labels = {
            "emp_id": "Employee",
            "no_of_days": "No of Days",
            "from_date": "From Date",
            "to_date": "To Date",
            "reason_for_leave": "Reason For Leave",
            "approved": "Approved",
        }
        widgets = {
            "from_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            ),
            "to_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            ),
        }


class LeaveUpdateForm(forms.ModelForm):
    emp_id = forms.ModelChoiceField(
        queryset=Employee.objects.all(),
        label="Employee",
    )

    class Meta:
        model = LeaveApplication
        fields = "__all__"
        labels = {
            "no_of_days": "No of Days",
            "from_date": "From Date",
            "to_date": "To Date",
            "reason_for_leave": "Reason For Leave",
            "approved": "Approved",
        }
        widgets = {
            "from_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            ),
            "to_date": forms.DateInput(
                attrs={
                    "type": "date",
                    "class": "form-control",
                    "style": "max-width: 200px;",
                }
            ),
        }


class DependentForm(forms.ModelForm):
    class Meta:
        model = Dependents
        fields = "__all__"
        exclude = ("member_id",)
        labels = {
            "emp_id": "Employee",
            "name": "Name",
            "relationship": "Relationship",
            "occupation": "Occupation",
        }


class DependentUpdateForm(forms.ModelForm):
    emp_id = forms.ModelChoiceField(
        queryset=Employee.objects.all(),
        label="Employee",
    )

    class Meta:
        model = Dependents
        fields = "__all__"
        labels = {
            "name": "Name",
            "relationship": "Relationship",
            "occupation": "Occupation",
        }
