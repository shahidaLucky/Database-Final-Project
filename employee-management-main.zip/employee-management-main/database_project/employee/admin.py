from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.translation import gettext_lazy as _
from .models import Employee, Department


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ("dept_id", "dept_name", "location")
    search_fields = ("dept_id", "dept_name", "location")
    ordering = ("dept_name",)
    fieldsets = (
        (_("Department Information"), {"fields": ("dept_id", "dept_name", "location")}),
    )


@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ("name", "emp_id", "email", "phone", "department", "hire_date")
    list_filter = ("department", "hire_date")
    search_fields = ("name", "emp_id", "email")
    ordering = ("name",)
    fieldsets = (
        (_("Personal Information"), {"fields": ("name", "emp_id")}),
        (_("Contact Information"), {"fields": ("email", "phone")}),
        (
            _("Employment Information"),
            {"fields": ("department", "designation", "salary", "hire_date")},
        ),
    )
    readonly_fields = ("emp_id",)

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        queryset = queryset.select_related("department")
        return queryset

    def department(self, obj):
        url = reverse("admin:app_department_change", args=[obj.department.pk])
        return format_html('<a href="{}">{}</a>', url, obj.department.dept_name)

    department.short_description = _("Department")
