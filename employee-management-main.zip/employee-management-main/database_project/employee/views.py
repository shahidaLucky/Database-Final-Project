from django.shortcuts import render, redirect, get_object_or_404
from .models import (
    Employee,
    Department,
    Project,
    EmployeeProject,
    Payroll,
    LeaveApplication,
    Dependents,
)
from .forms import (
    EmployeeForm,
    DepartmentForm,
    DepartmentUpdateForm,
    EmployeeUpdateForm,
    ProjectForm,
    ProjectUpdateForm,
    EmployeeProjectForm,
    EmployeeProjectUpdateForm,
    DependentForm,
    DependentUpdateForm,
    LeaveForm,
    LeaveUpdateForm,
    PayrollForm,
    PayrollUpdateForm,
)
from django.urls import reverse_lazy
from django.views.generic import DeleteView

# Create your views here.


def main_page(request):
    return render(request, "main_page.html")


def employee_list(request):
    employees = Employee.objects.all()
    context = {"employees": employees}
    return render(request, "employee_list.html", context)


def employee_create(request):
    if request.method == "POST":
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("employee_list")
    else:
        form = EmployeeForm()
    context = {"form": form, "departments": Department.objects.all()}
    return render(request, "employee_create.html", context)


def employee_detail(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    context = {"employee": employee}
    return render(request, "employee_detail.html", context)


def employee_update(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == "POST":
        form = EmployeeUpdateForm(request.POST, instance=employee)
        if form.is_valid():
            form.save()
            return redirect("employee_list")
    else:
        form = EmployeeForm(instance=employee)
    context = {"form": form}
    return render(request, "employee_form.html", context)


def employee_delete(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == "POST":
        employee.delete()
        return redirect("employee_list")
    return render(request, "employee_confirm_delete.html", {"employee": employee})


def department_list(request):
    departments = Department.objects.all()
    return render(request, "department_list.html", {"departments": departments})


def department_create(request):
    form = DepartmentForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect("department_list")
    return render(request, "department_form.html", {"form": form})


def department_detail(request, pk):
    department = get_object_or_404(Department, pk=pk)
    context = {"department": department}
    return render(request, "department_detail.html", context)


def department_update(request, pk):
    department = get_object_or_404(Department, pk=pk)
    if request.method == "POST":
        form = DepartmentUpdateForm(request.POST, instance=department)
        if form.is_valid():
            form.save()
            return redirect("department_list")
    else:
        form = DepartmentForm(instance=department)
    return render(request, "department_form.html", {"form": form})


def department_delete(request, pk):
    department = get_object_or_404(Department, pk=pk)

    if request.method == "POST":
        department.delete()
        return redirect("department_list")

    context = {"department": department}
    return render(request, "department_confirm_delete.html", context)


def project_list(request):
    projects = Project.objects.all()
    return render(request, "project/project_list.html", {"projects": projects})


def project_create(request):
    if request.method == "POST":
        form = ProjectForm(request.POST)
        if form.is_valid():
            project = form.save(commit=False)
            project.save()
            return redirect("project_list")
        else:
            print(form.errors)
    else:
        form = ProjectForm()
    return render(
        request,
        "project/project_create.html",
        {"form": form, "departments": Department.objects.all()},
    )


def project_detail(request, pk):
    project = get_object_or_404(Project, pk=pk)
    context = {"project": project}
    return render(request, "project/project_detail.html", context)


def project_update(request, pk):
    project = get_object_or_404(Project, pk=pk)
    if request.method == "POST":
        form = ProjectUpdateForm(request.POST, instance=project)
        if form.is_valid():
            form.save()
            return redirect("project_list")
    else:
        form = ProjectForm(instance=project)
    context = {"form": form}
    return render(request, "project/project_form.html", context)


def project_delete(request, pk):
    project = get_object_or_404(Project, pk=pk)
    if request.method == "POST":
        project.delete()
        return redirect("project_list")
    return render(request, "project/project_confirm_delete.html", {"project": project})


def employee_projects_list(request):
    emp_projects = EmployeeProject.objects.all()
    return render(request, "emp_project/list.html", {"emp_projects": emp_projects})


def employee_projects_create(request):
    if request.method == "POST":
        form = EmployeeProjectForm(request.POST)
        if form.is_valid():
            project = form.save(commit=False)
            project.save()
            return redirect("employee_projects_list")
        else:
            print(form.errors)
    else:
        form = EmployeeProjectForm()
    return render(
        request,
        "emp_project/create.html",
        {
            "form": form,
            "projects": Project.objects.all(),
            "employee": Employee.objects.all(),
        },
    )


def employee_projects_detail(request, pk):
    emp_project = get_object_or_404(EmployeeProject, pk=pk)
    context = {"emp_project": emp_project}
    return render(request, "emp_project/detail.html", context)


def employee_projects_update(request, pk):
    emp_project = get_object_or_404(EmployeeProject, pk=pk)
    if request.method == "POST":
        form = EmployeeProjectUpdateForm(request.POST, instance=emp_project)
        if form.is_valid():
            form.save()
            return redirect("employee_projects_list")
    else:
        form = EmployeeProjectForm(instance=emp_project)
    context = {"form": form}
    return render(request, "emp_project/form.html", context)


def employee_projects_delete(request, pk):
    emp_project = get_object_or_404(EmployeeProject, pk=pk)
    if request.method == "POST":
        emp_project.delete()
        return redirect("employee_projects_list")
    return render(
        request, "emp_project/confirm_delete.html", {"emp_projects": emp_project}
    )


def payroll_list(request):
    payroll = Payroll.objects.all()
    return render(request, "payroll/list.html", {"payrolls": payroll})


def payroll_create(request):
    if request.method == "POST":
        form = PayrollForm(request.POST)
        if form.is_valid():
            project = form.save(commit=False)
            project.save()
            return redirect("payroll_list")
        else:
            print(form.errors)
    else:
        form = PayrollForm()
    return render(
        request,
        "payroll/create.html",
        {"form": form, "employees": Employee.objects.all()},
    )


def payroll_detail(request, pk):
    payroll = get_object_or_404(Payroll, pk=pk)
    context = {"payroll": payroll}
    return render(request, "payroll/detail.html", context)


def payroll_update(request, pk):
    payroll = get_object_or_404(Payroll, pk=pk)
    if request.method == "POST":
        form = PayrollUpdateForm(request.POST, instance=payroll)
        if form.is_valid():
            form.save()
            return redirect("payroll_list")
    else:
        form = PayrollForm(instance=payroll)
    context = {"form": form}
    return render(request, "payroll/form.html", context)


def payroll_delete(request, pk):
    payroll = get_object_or_404(Payroll, pk=pk)
    if request.method == "POST":
        payroll.delete()
        return redirect("payroll_list")
    return render(request, "payroll/confirm_delete.html", {"payroll": payroll})


def leave_list(request):
    leave = LeaveApplication.objects.all()
    return render(request, "leave/list.html", {"leaves": leave})


def leave_create(request):
    if request.method == "POST":
        form = LeaveForm(request.POST)
        if form.is_valid():
            leave = form.save(commit=False)
            leave.save()
            return redirect("leave_list")
        else:
            print(form.errors)
    else:
        form = LeaveForm()
    return render(
        request,
        "leave/create.html",
        {"form": form, "employee": Employee.objects.all()},
    )


def leave_detail(request, pk):
    leave = get_object_or_404(LeaveApplication, pk=pk)
    context = {"leave": leave}
    return render(request, "leave/detail.html", context)


def leave_update(request, pk):
    leave = get_object_or_404(LeaveApplication, pk=pk)
    if request.method == "POST":
        form = LeaveUpdateForm(request.POST, instance=leave)
        if form.is_valid():
            form.save()
            return redirect("leave_list")
    else:
        form = LeaveForm(instance=leave)
    context = {"form": form}
    return render(request, "leave/form.html", context)


def leave_delete(request, pk):
    leave = get_object_or_404(LeaveApplication, pk=pk)
    if request.method == "POST":
        leave.delete()
        return redirect("leave_list")
    return render(request, "leave/confirm_delete.html", {"leave": leave})


def dependent_list(request):
    dependent = Dependents.objects.all()
    return render(request, "dependent/list.html", {"dependents": dependent})


def dependent_create(request):
    if request.method == "POST":
        form = DependentForm(request.POST)
        if form.is_valid():
            leave = form.save(commit=False)
            leave.save()
            return redirect("dependent_list")
        else:
            print(form.errors)
    else:
        form = DependentForm()
    return render(
        request,
        "dependent/create.html",
        {"form": form, "employee": Employee.objects.all()},
    )


def dependent_detail(request, pk):
    dependent = get_object_or_404(Dependents, pk=pk)
    context = {"dependent": dependent}
    return render(request, "dependent/detail.html", context)


def dependent_update(request, pk):
    dependent = get_object_or_404(Dependents, pk=pk)
    if request.method == "POST":
        form = DependentUpdateForm(request.POST, instance=dependent)
        if form.is_valid():
            form.save()
            return redirect("dependent_list")
    else:
        form = DependentForm(instance=dependent)
    context = {"form": form}
    return render(request, "dependent/form.html", context)


def dependent_delete(request, pk):
    dependent = get_object_or_404(Dependents, pk=pk)
    if request.method == "POST":
        dependent.delete()
        return redirect("dependent_list")
    return render(request, "dependent/confirm_delete.html", {"dependent": dependent})
