-- Procedure
DELIMITER &&
CREATE PROCEDURE getEmployeesByDepartmentAndDesignation(
    IN dept_name VARCHAR(50),
    IN designation VARCHAR(50)
)
BEGIN
    SELECT e.emp_id, e.name, d.dept_name, salary 
    FROM employee_employee e 
    JOIN employee_department d 
    ON e.department_id=d.dept_id 
    WHERE e.designation=designation and d.dept_name=dept_name;
END &&
DELIMITER ;

CALL getEmployeesByDepartmentAndDesignation('dummy', 'se');






-- Trigger
DELIMITER &&
CREATE TRIGGER insert_payroll AFTER INSERT ON employee_employee
FOR EACH ROW
  BEGIN
    SET @pay_day = LAST_DAY(NEW.hire_date);
    SET @curr_date = CURDATE();
    WHILE @pay_day < @curr_date DO
      INSERT INTO employee_payroll (emp_id_id, paid_date, amount)
      VALUES (NEW.emp_id, @pay_day, NEW.salary); 
      SET @pay_day = LAST_DAY(DATE_ADD(@pay_day, INTERVAL 1 DAY));
    END WHILE; 
  END &&
DELIMITER ;
